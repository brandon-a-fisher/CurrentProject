/**
 * A class maintaing data for a Savings Account. Is a subclass of BankAccount.
 * Can calculate monthly interest based on an annual interest rate and add this
 * interest to the account balance.
 **/
public class SavingsAccount extends BankAccount {
    
    private double annualInterestRate; // a percentage

    /**
     * Default constructor. Sets initial annualInterestRate to zero. Calls super default constructor.
     */
    public SavingsAccount() {
	super();
	setAnnualInterestRate(0);
    }

    /**
     * Constructor takes arguments for customer, initial balance, and initialAnnualInterestRate.
     *
     *
     *@param newCustomer
     *            Customer who will own this account.
     *@param initialBalance
     *            Starting Balance of account.
     *@param initialAnnualInterestRate
     *            Interest rate of the new account given as a percentage.
     *
     */
    public SavingsAccount(Customer newCustomer, double initialBalance, double initialAnnualInterestRate) {
	this();
        setCustomer(newCustomer);
	setBalance(initialBalance);
	setAnnualInterestRate(initialAnnualInterestRate);
    }

    /**
     * Returns a value for the annual interest rate of the savings account.
     * This should be a percentage.
     *
     * @return The annual interest rate of this account.
     */
    public double getAnnualInterestRate() {
	return annualInterestRate;
    }
    
    @Override
    /**
     * Returns a double value corresponding to the sum of 
     * the monthly fees and interest. If account balance
     * is below $1000, $5 in fees will be charged against
     * the account every month.
     */
    protected double getMonthlyFeesAndInterest(){
	double currentBalance = getBalance();
	double currentAnnualInterestRate = getAnnualInterestRate();
	double currentMonthlyInterestRate = currentAnnualInterestRate/(double)12;
	
	double fees = 0;
	double interestMade = 0;
	double monthlyFeesAndInterest = 0;
	
	if(currentBalance < 1000){
	    fees = 5;
	}

      	interestMade = currentBalance * (currentMonthlyInterestRate/(double)100);
	monthlyFeesAndInterest += (interestMade - fees);
	return monthlyFeesAndInterest;
    }
    
    /**
     * Sets the annual interest rate. This should be a percentage.
     *
     * @param newRate
     *            Sets a new annual interest rate for the account.
     */
    public void setAnnualInterestRate(double newRate) {
	if (newRate >= 0 && !(Double.isNaN(newRate)) && newRate != Double.POSITIVE_INFINITY)
	    annualInterestRate = newRate;
	else
	    System.out.println("Invalid input or tried to set interest rate" + '\n' + "to a negative value.");
    }
}
