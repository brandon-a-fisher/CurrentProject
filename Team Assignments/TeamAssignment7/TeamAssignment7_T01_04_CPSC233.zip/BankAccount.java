/**
 * A class maintaining the data for a Bank Account, including Customer and Balance.
 */
public abstract class BankAccount {

    private double balance;
    private Customer currentCustomer = new Customer();

    /**
     * The following constructor acts as the default constructor that takes in no
     * arguments. Default balance is zero, and default Customer is "No Name" with
     * ID 0.
     */
    public BankAccount() {
	setCustomer(new Customer());
	setBalance(0);
    }

    /**
     * Here, the bank account constructor takes in both a customer and an initial
     * balance.
     *
     * @param newCustomer
     *            Customer to whom the BankAccount belongs.
     * @param initialBalance
     *            Starting balance of the BankAccount.
     */
    public BankAccount(Customer newCustomer, double initialBalance) {
	this();
	setCustomer(newCustomer);
	setBalance(initialBalance);
    }
    
    /**
     * Returns the balance of a BankAccount object.
     *
     * @return Current balance of the account
     */
    public double getBalance() {
	return balance;
    }
    
    /**
     * Returns a copy of the Current Customer.
     *
     * @return Current customer that owns the account.
     */
    public Customer getCustomer() {
	Customer currentCustomerCopy = new Customer(currentCustomer);
	return currentCustomerCopy;
    }

    /**
     * Returns a double value corresponding to the sum of 
     * the monthly fees and interest.
     */
    protected abstract double getMonthlyFeesAndInterest();
     
    /**
     * Changes the balance of a BankAccount object.
     *
     * @param newBalance
     *            New balance of account.
     */
    protected void setBalance(double newBalance) {
	if (!(Double.isNaN(newBalance))
	    && newBalance != Double.POSITIVE_INFINITY
	    && newBalance != Double.NEGATIVE_INFINITY) {
	    balance = newBalance;
	}
    }
    
    /**
     * Sets the Current Customer.
     *
     * @param newCustomer
     *            New customer who owns this account.
     *
     */
    protected void setCustomer(Customer newCustomer) {
	currentCustomer.setName(newCustomer.getName());
	currentCustomer.setID(newCustomer.getID());
    }
    
    /**
     * depositAmount is added to your balance if it is a value greater than zero.
     *
     * @param depositAmount
     *            The amount to deposit in the account.
     */
    public void deposit(double depositAmount) {
	if (depositAmount > 0
	    && depositAmount != Double.POSITIVE_INFINITY
	    && !(Double.isNaN(depositAmount))) {
	    setBalance(getBalance() + depositAmount);
	} else {
	    System.out.println("Tried to deposit a negative or zero amount."
			       + '\n'
			       + "Please enter a positive value.");
	}
    }

    /**
     * Allows you to withdraw as long as the amount withdrawn
     * does not cause balance to fall below zero.
     *
     * @param withdrawAmount
     *            The amount to withdraw from the account.
     */
    public void withdraw(double withdrawAmount) {
	if (getBalance() - withdrawAmount >=0
	    && withdrawAmount > 0
	    && withdrawAmount != Double.POSITIVE_INFINITY
	    && !(Double.isNaN(withdrawAmount))) {
	    setBalance(getBalance() - withdrawAmount);
	} else {
	    System.out.println("I'm sorry you have exceeded your overdraft"
			       + '\n'
			       + "amount or you've tried to withdraw a negative"
			       + '\n'
			       + "or zero amount.");
	}
    }

    /**
     * Withdraws money from the current BankAccount, and deposits an
     * equivalent amount into another BankAccount given as an argument.
     *
     *@param amount
     *         Double representing an amount to transfer.
     *
     *@param toAccount
     *         BankAccount object representing the account to transfer the amount to.
     */
    public void transfer(double amount, BankAccount toAccount){
	double originalBalance = getBalance();
	double whatToTransfer = 0;
	this.withdraw(amount);
	// Check if withdraw was succesful by checking if the
	// balance has changed, and if so transfer the difference
	// between the originalBalance and current balance to
	// the BankAccount given as an argument. Print error message
	// if withdraw was unsuccesful.
	if(balance < originalBalance){
	    whatToTransfer = (originalBalance - balance);
	    toAccount.deposit(whatToTransfer);
	} else {
	    System.out.println("Transfer was unsucessful. Withdraw failed. Either you input" 
			       + '\n'
			       + "an invalid transfer amount or you have insufficent funds.");
	}
    }

    /**
     * Updates balance by adding the amount of monthly fees and interest
     * accumulated.
     */
    public void monthEndUpdate(){
	double currentBalance = getBalance();
	double feesAndInterest = getMonthlyFeesAndInterest();
	setBalance(currentBalance + feesAndInterest);
    }
}
