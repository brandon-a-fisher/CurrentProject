/**
 * A class maintaining the data for a ChequingAccount, including overdraftAmount
 * and overdraftFee. Extends BankAccount class.
 */
public class ChequingAccount extends BankAccount{

    private double overdraftAmount;
    private double overdraftFee;

    /** 
     * Default constructor that takes in an argument for the overdraftFee, and sets overDraftAmount
     * to a default of 100.
     *
     *@param newOverdraftFee
     *              A double representing a fee applied to this account when using overdraft.
     */
    public ChequingAccount(double newOverdraftFee){
	super();
	setOverdraftFee(newOverdraftFee);
	setOverdraftAmount(100);
    }
    
    /** 
     * Constructor takes in arguments for starting balance, accountholder and overdraft fee. 
     *
     *@param newCustomer
     *               A Customer object representing the account holder of the new account.
     *
     *@param initialBalance
     *               A double representing the starting balance of the account at opening.
     *
     *@param newOverdraftFee
     *               A double representing a fee applied to this account when making a transfer.
     */
    public ChequingAccount(Customer newCustomer, double initialBalance, double newOverdraftFee){
	this(newOverdraftFee);
	setCustomer(newCustomer);
	setBalance(initialBalance);
    }
    
    /**
     * Returns the overdraftAmount of a ChequingAccount object.
     *
     *@return An integer representing the current overdraftAmount of the BankAccount.
     */
    public double getOverdraftAmount() {
	return overdraftAmount;
    }
        
    /**
     * Returns the overdraftFee of a ChequingAccount object.
     *
     *@return An integer representing the current overdraftFee of the BankAccount.
     */
    public double getOverdraftFee() {
	return overdraftFee;
    }

    @Override
    /**
     * Returns a double value corresponding to the sum of 
     * the monthly fees and interest. Will charge no fees if
     * the balance is above zero, but will charge 20% of the 
     * current balance if the balance is below zero.
     */
    protected double getMonthlyFeesAndInterest(){
	double currentBalance = getBalance();
	double fees = 0;
	if(currentBalance < 0)
	    fees = currentBalance*0.2;
	return fees;
    }
    
    /**
     * Changes the overdraftAmount of a ChequingAccount object.
     *
     * @param newOverdraftAmount
     *            New maximum overdraft amount of account.
     */
    public void setOverdraftAmount(double newOverdraftAmount) {
	if (!(Double.isNaN(newOverdraftAmount))
	    && newOverdraftAmount != Double.NEGATIVE_INFINITY
	    && newOverdraftAmount != Double.POSITIVE_INFINITY) {
	    overdraftAmount = newOverdraftAmount;
	}
    }

    /**
     * Changes the overdraftFee of a ChequingAccount object.
     *
     * @param newOverdraftFee
     *            New overdraft fee of an account.
     */
    public void setOverdraftFee(double newOverdraftFee) {
	if (!(Double.isNaN(newOverdraftFee))
	    && newOverdraftFee != Double.NEGATIVE_INFINITY
	    && newOverdraftFee != Double.POSITIVE_INFINITY) {
	    overdraftFee = newOverdraftFee;
	}
    }

    @Override    
    /**
     * Allows you to withdraw as long as you do not exceed (balance +
     * overdraftAmount), and applies overdraft fee if you use overdraft.
     *
     * @param withdrawAmount
     *            The amount to withdraw from the account.
     */
    public void withdraw(double withdrawAmount) {
	if (withdrawAmount <= (getBalance() + overdraftAmount)
	    && withdrawAmount > 0
	    && withdrawAmount != Double.POSITIVE_INFINITY
	    && !(Double.isNaN(withdrawAmount))) {
	    setBalance(getBalance() - withdrawAmount);
	    // Apply overdraft fee if balance is below 0.
	    if(getBalance() < 0 )
	    setBalance(getBalance()-overdraftFee);
	} else {
	    System.out.println("I'm sorry you have exceeded your overdraft" + '\n'
			       + "amount or you've tried to withdraw a negative" + '\n'
			       + "or zero amount.");
	}
    }

    @Override
    /**
     * Withdraws money from the current BankAccount, and deposits an
     * equivalent amount into another BankAccount given as an argument.
     * Keeps whether or not an overdraft fee is applied in mind, when 
     * calculating amount to transfer.
     *
     *@param amount
     *         Double representing an amount to transfer.
     *
     *@param toAccount
     *         BankAccount object representing the account to transfer the amount to.
     */
    public void transfer(double amount, BankAccount toAccount){
	double originalBalance = getBalance();
	double whatToTransfer = 0;

	this.withdraw(amount);
	
	// Check if withdraw was succesful by checking if the
	// balance has changed, and if so transfer the difference
	// between the originalBalance and current balance to
	// the BankAccount given as an argument. Print error message
	// if withdraw was unsuccesful.
	if(getBalance() < originalBalance){
	    // Must subtract overDraftFee from original balance, otherwise we'll
	    // find the difference of the balances plus the overdraft fee, and
	    // transfer fake money equivalent to the value of the overdraft fee.
	    whatToTransfer = (originalBalance - getOverdraftFee()) - getBalance();
	    toAccount.deposit(whatToTransfer);
	} else {
	    System.out.println("Transfer was unsucessful. Withdraw failed. Either you input" 
			       + '\n'
			       + "an invalid transfer amount or you have insufficent funds.");
	}
    }
}


